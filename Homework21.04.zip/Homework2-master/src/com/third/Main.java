package com.third;

public class Main {
    public static void main(String[] args) {
        int floor = 9;
        for (int i = 9; i >= 0; i--){
            switch(i){
                case 9:
                    System.out.println("Здравей Мими.");
                    break;
                case 8:
                    System.out.println("Здравей Веси.");
                    break;
                case 7:
                    System.out.println("Здравей Лили.");
                    break;
                case 6:
                    System.out.println("Здравей Роси.");
                    break;
                case 5:
                    System.out.println("Здравей Ваня.");
                    break;
                case 4:
                    System.out.println("Здравей Пепи.");
                    break;
                case 3:
                    System.out.println("Здравей Габи.");
                    break;
                case 2:
                    System.out.println("Здравей Яна.");
                    break;
                case 1:
                    System.out.println("Здравей Цеци.");
                    break;
                case 0:
                    System.out.println("Ауч!!!");
            }
        }
    }
}
