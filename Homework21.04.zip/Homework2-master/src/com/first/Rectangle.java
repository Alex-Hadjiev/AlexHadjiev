package com.first;

public class Rectangle {
    public double calcArea(double a, double b){
        return a * b;
    }

    public double calcPerimeter(double a, double b){
        return 2*a + 2* b;
    }
}
